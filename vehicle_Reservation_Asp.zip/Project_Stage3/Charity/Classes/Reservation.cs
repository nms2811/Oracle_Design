﻿/*
Student Names:  Minseop Noh-128546157
                Ehsan Sabery Ghomy - 051519148
                Sureshkumar Nagaratnam - 052396140
OLS655 Final Project Stage 3 
Team Number: 1
Due Date: Aug 7, 2019
Professor’s Name: Sanja Kliska
Title: ASP.NET Application for Stage3
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Charity
{
    public class Reservation
    {
        public string Licence_Plate { get; private set; }
        public string Model { get; private set; }
        public string Type { get; private set; }
        public string First_Name { get; private set; }
        public string Last_Name { get; private set; }

        public Reservation(string licence_plate, string model, string type, string first_name, string last_name)
        {
            this.Licence_Plate = licence_plate;
            this.Model = model;
            this.Type = type;
            this.First_Name = first_name;
            this.Last_Name = last_name;
        }
    }
}