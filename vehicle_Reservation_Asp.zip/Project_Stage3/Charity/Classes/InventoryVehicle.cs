﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Charity
{
    public class InventoryVehicle
    {
        public string Make { get; private set; }
        public string Model { get; private set; }
        public string Description { get; private set; }
        public string Licence_Plate { get; private set; }


        public InventoryVehicle(string make, string model, string description, string licence_plate)
        {
            this.Make = make;
            this.Model = model;
            this.Description = description;
            this.Licence_Plate = licence_plate;

        }
    }
}