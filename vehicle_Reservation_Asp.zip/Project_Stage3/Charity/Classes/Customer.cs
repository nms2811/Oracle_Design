﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Charity
{
    public class Customer
    {
        public string Customer_ID { get; private set; }

        public Customer(string customer_id)
        {
            this.Customer_ID = customer_id;
        }
    }
}