﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Charity
{
    public class VehicleType
    {
        public string Type { get; private set; }

        public VehicleType(string type)
        {
            this.Type = type;

        }
    }
}