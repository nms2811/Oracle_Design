﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Charity
{
    public partial class Home : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
                GetReservations();
            lblError.Text = string.Empty; // Clear any previous error           
        }

        private void GetReservations()
        {
            LoginInfo login = (LoginInfo)Session["login"];
            RentalReservationDAO rentalReservationDAO = new RentalReservationDAO(login.UserName, login.Password);
            List<Reservation> reservations = rentalReservationDAO.LoadAll();


            if (!reservations.Any())
            {
                lblOutput.Text = "You have No Reservation(s).";
            }
            else
            {
                lblOutput.Text = "Please View the list below for your reservation(s):";

            }

            gvReservations.DataSource = reservations;
            gvReservations.DataBind();

        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("~/Home.aspx");
        }

        protected void gvReservations_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            LoginInfo login = (LoginInfo)Session["login"];
            RentalReservationDAO rentalReservationDAO = new RentalReservationDAO(login.UserName, login.Password);
            int index = Convert.ToInt32(e.CommandArgument);
            string licence_plate = Convert.ToString(gvReservations.Rows[index].Cells[1].Text);
            lblError.Text = string.Empty;
            if (e.CommandName == "DELETE")
            {
                try
                {
                    rentalReservationDAO.DeleteByLicence_Plate(licence_plate);
                    GetReservations();
                }
                catch (Exception ex)
                {
                    lblError.Text = ex.Message;
                }
            }
        }





        protected void gvReservations_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true; // to prevent on-screen row deleting
        }

        protected void btnNewReservation_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/NewReservation.aspx");
        }
    }
}