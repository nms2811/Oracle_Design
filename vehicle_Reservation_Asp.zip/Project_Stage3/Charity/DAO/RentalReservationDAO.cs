﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.OracleClient;

namespace Charity
{
    public class RentalReservationDAO
    {

        private string UserName { get; set; }
        private string Password { get; set; }

        public RentalReservationDAO(string UserName, string Password)
        {
            this.UserName = UserName;
            this.Password = Password;
        }

        public List<Reservation> LoadAll()
        {
            OracleConnection conn = new OracleConnection(String.Format("Data Source=Neptune; User Id={0}; Password={1}", UserName, Password));
            string sqlStatement = "select rental.licence_plate, vehicle.model, type, first_name, last_name from vehicle";
            sqlStatement += " inner join vehicle_properties on (vehicle.make = vehicle_properties.make)";
            sqlStatement += " and (vehicle.model = vehicle_properties.model)";
            sqlStatement += " inner join rental on rental.licence_plate = vehicle.licence_plate";
            sqlStatement += " inner join customer on customer.customer_id = rental.customer_id";
            OracleCommand cmd = new OracleCommand(sqlStatement, conn);
            OracleDataAdapter da = new OracleDataAdapter(cmd);
            DataTable dt = new DataTable();
            List<Reservation> reservations = new List<Reservation>();

            da.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                string licence_plate = Convert.ToString(dr["licence_plate"]);
                string model = Convert.ToString(dr["model"]);
                string type = Convert.ToString(dr["type"]);
                string first_name = Convert.ToString(dr["first_name"]);
                string last_name = Convert.ToString(dr["last_name"]);
                reservations.Add(new Reservation(licence_plate, model, type, first_name, last_name));
            }
            return reservations;
        }



        public void DeleteByLicence_Plate(string licence_plate)
        {
            OracleConnection conn = new OracleConnection(String.Format("Data Source=Neptune; User Id={0}; Password={1}", UserName, Password));
            OracleCommand cmd = new OracleCommand("DELETE FROM rental WHERE licence_plate = :licence_plate", conn);

            cmd.Parameters.AddWithValue(":licence_plate", licence_plate);

            conn.Open();
            try
            {
                cmd.ExecuteNonQuery();
            }
            finally
            {
                conn.Close();
            }
        }


        public List<VehicleType> ShowTypes()
        {
            OracleConnection conn = new OracleConnection(String.Format("Data Source=Neptune; User Id={0}; Password={1}", UserName, Password));
            OracleCommand cmd = new OracleCommand("select distinct type from vehicle_properties order by type", conn);
            OracleDataAdapter da = new OracleDataAdapter(cmd);
            DataTable dt = new DataTable();
            List<VehicleType> types = new List<VehicleType>();

            da.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                string type = Convert.ToString(dr["type"]);
                types.Add(new VehicleType(type));
            }
            return types;
        }

        public List<InventoryVehicle> ShowInventoryVehicles(string type)
        {
            OracleConnection conn = new OracleConnection(String.Format("Data Source=Neptune; User Id={0}; Password={1}", UserName, Password));
            string list_all = "select distinct vehicle_properties.make, vehicle_properties.model, description, vehicle.licence_plate";
            list_all += " from vehicle_properties inner join vehicle on (vehicle_properties.make = vehicle.make)";
            list_all += " and (vehicle_properties.model = vehicle.model)";
            list_all += " where vehicle_properties.type = :type";
            list_all += " order by vehicle.licence_plate";

            OracleCommand cmd = new OracleCommand(list_all, conn);
            cmd.Parameters.AddWithValue(":type", type);
            OracleDataAdapter da = new OracleDataAdapter(cmd);
            DataTable dt = new DataTable();
            List<InventoryVehicle> all_vehicles = new List<InventoryVehicle>();

            da.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                string make1 = Convert.ToString(dr["make"]);
                string model1 = Convert.ToString(dr["model"]);
                string description1 = Convert.ToString(dr["description"]);
                string licence_plate1 = Convert.ToString(dr["licence_plate"]);
                all_vehicles.Add(new InventoryVehicle(make1, model1, description1, licence_plate1));
            }


            string just_reserved = "select vehicle_properties.make, vehicle_properties.model, description, vehicle.licence_plate";
            just_reserved += " from vehicle_properties inner join vehicle on (vehicle_properties.make = vehicle.make)";
            just_reserved += " and (vehicle_properties.model = vehicle.model)";
            just_reserved += " inner join rental on vehicle.licence_plate = rental.licence_plate Where type = :type";
            just_reserved += " order by vehicle.licence_plate";

            OracleCommand cmd1 = new OracleCommand(just_reserved, conn);
            cmd1.Parameters.AddWithValue(":type", type);
            OracleDataAdapter da1 = new OracleDataAdapter(cmd1);
            DataTable dt1 = new DataTable();
            List<InventoryVehicle> reserved_vehicles = new List<InventoryVehicle>();

            da1.Fill(dt1);

            foreach (DataRow dr in dt1.Rows)
            {
                string make1 = Convert.ToString(dr["make"]);
                string model1 = Convert.ToString(dr["model"]);
                string description1 = Convert.ToString(dr["description"]);
                string licence_plate1 = Convert.ToString(dr["licence_plate"]);
                reserved_vehicles.Add(new InventoryVehicle(make1, model1, description1, licence_plate1));
            }

            List<InventoryVehicle> upForReservetions = new List<InventoryVehicle>();
            int[] value = new int[all_vehicles.Count];

            for (int k = 0; k < all_vehicles.Count; k++)
            {
                value[k] = -1;
            }
            for (int i = 0; i < all_vehicles.Count; i++)
            {
                for (int j = 0; j < reserved_vehicles.Count; j++)
                {
                    if (all_vehicles[i].Licence_Plate == reserved_vehicles[j].Licence_Plate)
                    {
                        value[i] = i;
                    }
                }
            }

            for (int i = 0; i < all_vehicles.Count; i++)
            {
                if (value[i] == -1)
                {
                    upForReservetions.Add(new InventoryVehicle(all_vehicles[i].Make, all_vehicles[i].Model, all_vehicles[i].Description, all_vehicles[i].Licence_Plate));
                }

            }



            return upForReservetions;
        }

        public void ReserveAVehicle(string startD, string endD, string cus_id, string licence_plate)
        {

            OracleConnection conn = new OracleConnection(String.Format("Data Source=Neptune; User Id={0}; Password={1}", UserName, Password));
            OracleCommand cmd = new OracleCommand();
            cmd.Connection = conn;

            cmd.CommandType = CommandType.Text;

            conn.Open();
            try
            {
                string sql = "INSERT INTO rental (start_date, end_date, customer_id, licence_plate) VALUES";
                sql += " (TO_DATE( :startDate ,'YYYY-MM-DD'),TO_DATE( :endDate ,'YYYY-MM_DD'), :customer_id , :licence_plate )";
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue(":startDate", startD);
                cmd.Parameters.AddWithValue(":endDate", endD);
                cmd.Parameters.AddWithValue(":customer_id", cus_id);
                cmd.Parameters.AddWithValue(":licence_plate", licence_plate);
                cmd.ExecuteNonQuery();
            }
            finally
            {
                conn.Close();
            }
        }

        public string GetCustomerID()
        {
            OracleConnection conn = new OracleConnection(String.Format("Data Source=Neptune; User Id={0}; Password={1}", UserName, Password));
            OracleCommand cmd = new OracleCommand("select customer_id from customer", conn);
            OracleDataAdapter da = new OracleDataAdapter(cmd);
            DataTable dt = new DataTable();
            List<Customer> customers = new List<Customer>();

            da.Fill(dt);

            foreach (DataRow dr in dt.Rows)
            {
                string customer_id = Convert.ToString(dr["customer_id"]);
                customers.Add(new Customer(customer_id));
            }
            return customers[0].Customer_ID;  //returning first row customer id for simplicity.
        }
    }
}