﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Charity
{
    public partial class NewReservation : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoginInfo login = (LoginInfo)Session["login"];
                RentalReservationDAO rentalReservationDAO = new RentalReservationDAO(login.UserName, login.Password);
                ddlType.DataSource = rentalReservationDAO.ShowTypes();
                ddlType.DataTextField = "type";

                ddlType.DataBind();
                calFrom.SelectedDate = DateTime.Today;
                calTo.SelectedDate = DateTime.Today;
                display(false);

            }
            lblError.Text = string.Empty; // Clear any previous error
        }
        protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
        {

            LoginInfo login = (LoginInfo)Session["login"];
            RentalReservationDAO rentalReservationDAO = new RentalReservationDAO(login.UserName, login.Password);
            string type = Convert.ToString(ddlType.SelectedValue);
            List<InventoryVehicle> inventoryVehicles = rentalReservationDAO.ShowInventoryVehicles(type);
            gvNewReservation.DataSource = inventoryVehicles;
            gvNewReservation.DataBind();

            if (!inventoryVehicles.Any())
            {

                display(false);
                if (type == "0")
                {
                    lblOutputText.Text = "";
                }
                else
                {
                    string output1 = "There are not any vehicles left in the inventory for reservation. <br />Please Select another Vehicle Type.";
                    lblOutputText.Text = output1;
                }
            }
            else
            {
                display(true);
                lblOutputText.Text = "Please look at the list below to choose a Vehicle to reserve:";
            }




        }
        public void display(bool swit)
        {
            calFrom.Visible = swit;
            calTo.Visible = swit;
            lblFrom.Visible = swit;
            lblTo.Visible = swit;

        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Home.aspx");
        }

        protected void btnLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("~/Login.aspx");
        }

        protected void gvNewReservation_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            LoginInfo login = (LoginInfo)Session["login"];
            RentalReservationDAO rentalReservationDAO = new RentalReservationDAO(login.UserName, login.Password);
            int index = Convert.ToInt32(e.CommandArgument);
            string licence_plate = Convert.ToString(gvNewReservation.Rows[index].Cells[4].Text);


            if (calFrom.SelectedDate < DateTime.Today)
            {
                lblError.Text = "From Date Should Be At least from Today: " + DateTime.Now.ToString();
                return;
            }
            else if (calFrom.SelectedDate > calTo.SelectedDate)
            {
                lblError.Text = "To Date Should Be At least be same as From Date: " + calFrom.SelectedDate.ToString();
                return;
            }

            string startDate = calFrom.SelectedDate.ToShortDateString();
            string endDate = calTo.SelectedDate.ToShortDateString();
            lblError.Text = string.Empty;
            if (e.CommandName == "RESERVE")
            {
                try
                {
                    string cust_id = rentalReservationDAO.GetCustomerID();
                    rentalReservationDAO.ReserveAVehicle(startDate, endDate, cust_id, licence_plate);
                    Response.Redirect("~/Home.aspx");
                }
                catch (Exception ex)
                {
                    lblError.Text = ex.Message;
                }
            }
        }



        protected void gvNewReservation_RowReserve(object sender, GridViewDeleteEventArgs e)
        {
            e.Cancel = true; // to prevent on-screen row deleting
        }


    }
}